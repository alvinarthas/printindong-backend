<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Methodbayar extends Model
{
    protected $table = 'methodbayar';

    protected $fillable = [
        'nama','icon'
    ];
}